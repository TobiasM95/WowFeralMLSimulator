#pragma once

class Buff
{

};