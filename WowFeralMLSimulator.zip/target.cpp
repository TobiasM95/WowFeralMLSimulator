#include "target.h"
#include "skill.h"

#include <iostream>

void Target::resolve(Skill& s)
{
	//temporary, do way more stuff here
	received_dmg += s.calc_instant_dmg();
}

void Target::tick(float time_delta)
{
	fight_duration += time_delta;
	dps = received_dmg / fight_duration;
	std::cout << "Fight duration: " << fight_duration << " - DPS: " << dps << "      \r";
}

