#include "player.h"
#include "feral_skills.h"


Player::Player(float wep_dps, int agility, float crit, float haste, float mastery, 
	float versatility) :
	wep_dps(wep_dps), agility(agility), crit(crit), haste(haste), mastery(mastery), 
	versatility(versatility)
{


}

void Player::tick(float time_delta, Target& t)
{
	autoattack_timer += time_delta;
	gcd_timer = std::max(gcd_timer - time_delta, 0.0f);
	if (autoattack_timer > base_auto_attack_speed) 
	{
		autoattack_timer = 0.0f;
		AutoAttack a(*this);
		t.resolve(a);
	}
	
}