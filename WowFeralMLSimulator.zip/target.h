#pragma once

//#include "skill.h"
//THIS IS A CIRCULAR INCLUDE
class Skill;

class Target
{
private:
	float received_dmg = 0;
	float fight_duration = 0;
	float dps = 0;
public:
	void resolve(Skill& s);
	void tick(float time_delta);
};